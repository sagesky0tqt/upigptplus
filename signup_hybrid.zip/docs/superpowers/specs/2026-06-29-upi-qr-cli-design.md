# UPI QR CLI standalone

## Goal

Tambahkan folder Python baru yang hanya fokus untuk generate QR UPI lewat CLI, tanpa perlu menjalankan web UI atau bot Telegram.

## Scope

- Input utama:
  - `--session-file <path>` untuk `session.json`
  - `--access-token <token>` untuk paste token langsung dari CLI
  - `--email <email>` wajib bila pakai `--access-token`
  - `--cookie-header <header>` opsional
- Output:
  - file PNG QR di path yang dipilih
  - ringkasan JSON singkat ke stdout
- Entry point:
  - `python -m upi_qr_cli`

## Proposed structure

Folder baru:

```text
upi_qr_cli/
  __init__.py
  __main__.py
  cli.py
```

`cli.py` hanya bertugas parse argumen, load auth, lalu memanggil flow yang sudah ada.

## Architecture

Gunakan wrapper tipis di atas `web/upi_runner.run_upi_qr_probe`.

Alur:

1. CLI parse input.
2. Jika `--session-file` ada, baca JSON dan ambil `accessToken`, `user.email`, dan cookies.
3. Jika hanya `--access-token` ada, bangun auth in-memory dari token + email + cookie header opsional.
4. Bangun config UPI dan panggil runner yang sudah ada.
5. Simpan PNG QR ke `--qr-out`.
6. Cetak hasil ringkas ke stdout.

## Why this approach

1. Paling kecil perubahan.
2. Reuse flow yang sudah teruji.
3. Tidak menduplikasi logic checkout/Stripe/QR.
4. Mudah dipakai dari terminal.

## Behavior details

- `--session-file` dan `--access-token` saling eksklusif.
- Jika `--access-token` dipakai tanpa `--email`, CLI harus fail-fast.
- Jika `--qr-out` tidak diberikan, gunakan default path lokal yang jelas.
- Watermark tetap support, default mengikuti repo.
- Proxy support tetap ada lewat flag/env.

## Error handling

- JSON session invalid → exit code non-zero + pesan singkat.
- Token/email kurang → fail-fast.
- Flow checkout/Stripe gagal → propagate error ringkas.
- File output parent directory akan dibuat otomatis.

## Testing

- Tambah smoke test kecil untuk parse argumen dan load auth.
- Tambah check untuk mode:
  - session-file
  - access-token + email
- Verifikasi syntax import path baru.

## Non-goals

- Tidak membuat service baru.
- Tidak mengubah web UI.
- Tidak menambah flow pembayaran baru.

